/**
 * Provide some common and generic tools that are used throughout the application.
 */
package se.ltu.softwareengineering.tool;