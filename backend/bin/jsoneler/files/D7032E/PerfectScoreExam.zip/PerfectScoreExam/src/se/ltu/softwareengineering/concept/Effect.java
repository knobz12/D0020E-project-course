package se.ltu.softwareengineering.concept;

public enum Effect {
    AlterDamages,
    AlterArmor,
    AlterCardCost,
    AlterMaxHealth,
    AlterRerollNumber,
    GainStars,
    GainEnergy,
    GainHearts,
    DealDamages
}
