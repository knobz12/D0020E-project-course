package se.ltu.softwareengineering.communication.message;

class OpenQuestion extends Question {
    OpenQuestion(String question) {
        super(question, null, -1);
    }
}
