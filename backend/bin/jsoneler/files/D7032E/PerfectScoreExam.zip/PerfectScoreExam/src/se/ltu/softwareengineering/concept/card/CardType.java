package se.ltu.softwareengineering.concept.card;

public enum CardType {
    Keep,
    Discard
}
