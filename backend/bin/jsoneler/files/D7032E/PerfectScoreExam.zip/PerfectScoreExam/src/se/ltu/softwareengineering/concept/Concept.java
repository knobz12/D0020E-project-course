package se.ltu.softwareengineering.concept;

public interface Concept {
}
